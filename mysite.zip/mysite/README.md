# 🌐 MySite — Your Personal Website

A full website with a Shop, Video feed, Games, and User Accounts.
Built with plain HTML, CSS, and JavaScript — no complicated tools needed.

---

## 📁 File Structure

```
mysite/
├── index.html        ← The whole website (one file)
├── css/
│   └── style.css     ← All the styling
├── js/
│   ├── app.js        ← Core logic (auth, cart, routing)
│   └── pages.js      ← Shop, Videos, Games, Profile logic
└── README.md         ← This file
```

---

## 🚀 How to Run It Locally (on your computer)

### Option A — Just open it (quickest)
1. Download all the files
2. Double-click `index.html`
3. It opens in your browser and works!

### Option B — Use VS Code (recommended for editing)
1. Download **VS Code** free at code.visualstudio.com
2. Install the **Live Server** extension inside VS Code
3. Open the `mysite` folder in VS Code
4. Right-click `index.html` → "Open with Live Server"
5. Your site opens at `http://localhost:5500`

---

## ✏️ How to Customize It

### Change the site name
Open `index.html` and find:
```html
<div class="nav-logo">MySite</div>
```
Change `MySite` to whatever you want.

### Change colors
Open `css/style.css` — the top section has all the colors:
```css
--accent:  #00d4ff;   /* main blue color */
--accent2: #7c3aed;   /* purple accent */
```
Change those hex codes to any color you like.

### Add products to the Shop
Open `js/pages.js` and find `const PRODUCTS = [` near the top.
Copy one of the existing blocks and change the details:
```js
{ id: 7, name: "My New Product", price: 9.99, category: "merch", emoji: "🎁", desc: "Description here." },
```
Give each product a unique `id` number.

### Add videos
Open `js/pages.js` and find `const VIDEOS = [`.
Add a YouTube video like this:
```js
{ id: 4, title: "My Video Title", thumb: "🎬", src: "https://www.youtube.com/embed/YOUR_VIDEO_ID", type: "youtube", desc: "Description." },
```
To get the video ID: go to YouTube, copy the part after `?v=` in the URL.
Example: `youtube.com/watch?v=ABC123` → ID is `ABC123`

### Add more games
Open `js/pages.js` and find `const GAMES = [`.
Add an entry, then write a `startYourGame()` function below the others.

---

## 🔥 How to Add Real Accounts with Firebase (optional)

Right now accounts are saved in your browser only (demo mode).
To make real accounts that persist across devices:

1. Go to **firebase.google.com** → Create a free account
2. Click "Add project" → name it anything → Create
3. In your project, click the **</>** icon (Web app)
4. Copy the config values shown
5. Open `js/app.js` and paste them here:
```js
const firebaseConfig = {
  apiKey:            "paste here",
  authDomain:        "paste here",
  ...
};
```
6. Also change: `const DEMO_MODE = false;`
7. In Firebase Console → Authentication → Sign-in method → Enable **Email/Password**

---

## 💳 How to Add Real Payments (optional)

The checkout currently shows a demo message. To take real payments:

1. Sign up at **stripe.com** (free account)
2. Use **Stripe Checkout** — they have a simple embed guide
3. In `js/pages.js` find the `checkout()` function and add your Stripe code there

---

## 🌍 How to Publish on Netlify (easiest)

1. Go to **netlify.com** → Sign up free
2. Drag the entire `mysite` **folder** into the deploy box
3. Your site is live! You'll get a URL like `your-site.netlify.app`
4. To update: just drag the folder again

## 🐙 How to Publish on GitHub Pages

1. Go to **github.com** → Create a new repository (name it `mysite`, set to Public)
2. Upload ALL the files (keep the folders — css/ and js/ must stay organized)
3. Go to **Settings → Pages → Branch → main → Save**
4. Site goes live at `https://yourusername.github.io/mysite`

⚠️ Important: When uploading to GitHub, upload the files INSIDE the mysite folder,
not the folder itself. GitHub needs `index.html` to be at the root level.

---

## 🧩 Things You Can Add Later

- A blog / posts section
- A photo gallery
- A contact form (use Formspree.io — free & easy)
- Custom domain name (buy one at namecheap.com for ~$10/year)
- Dark/light mode toggle

---

## 🆘 Need Help?

- Ask Claude to help modify any part of the code
- Just paste the file contents and describe what you want changed
