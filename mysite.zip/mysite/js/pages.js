/* ============================================
   pages.js — Page-specific logic
   Shop, Videos, Games, Profile, Cart
   ============================================ */

// ══════════════════════════════════════════
//  SHOP
// ══════════════════════════════════════════

// 🔧 ADD YOUR PRODUCTS HERE — just copy/paste a block
const PRODUCTS = [
  { id: 1, name: "Cool Sticker Pack",    price: 4.99,  category: "merch",       emoji: "🎨", desc: "10 high-quality vinyl stickers. Waterproof & durable." },
  { id: 2, name: "Mystery Box",          price: 19.99, category: "mystery",     emoji: "📦", desc: "What's inside? Only one way to find out!" },
  { id: 3, name: "Enamel Pin",           price: 8.99,  category: "merch",       emoji: "📌", desc: "Hard enamel pin with gold backing. Limited edition." },
  { id: 4, name: "Digital Wallpaper Set",price: 2.99,  category: "digital",     emoji: "🖼️", desc: "10 exclusive wallpapers for phone & desktop." },
  { id: 5, name: "Tote Bag",             price: 14.99, category: "merch",       emoji: "👜", desc: "Heavy canvas tote. Perfect for everyday use." },
  { id: 6, name: "Gaming Mouse Pad",     price: 12.99, category: "accessories", emoji: "🖱️", desc: "Extended desk mat with stitched edges." },
];

let shopFilter = 'all';

function initShop() {
  renderProducts();
}

function renderProducts() {
  const grid = document.getElementById('productGrid');
  const filtered = shopFilter === 'all' ? PRODUCTS : PRODUCTS.filter(p => p.category === shopFilter);

  if (!filtered.length) {
    grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1"><div class="empty-icon">🛍️</div><h3>No products here yet</h3></div>`;
    return;
  }

  grid.innerHTML = filtered.map(p => `
    <div class="card product-card">
      <div class="product-img">${p.emoji}</div>
      <div class="product-body">
        <div class="product-category badge badge-accent">${p.category}</div>
        <h3 class="product-name">${p.name}</h3>
        <p class="product-desc">${p.desc}</p>
        <div class="product-footer">
          <span class="product-price">$${p.price.toFixed(2)}</span>
          <button class="btn btn-primary btn-sm" onclick="addToCart(${JSON.stringify(p).replace(/"/g,'&quot;')})">Add to Cart</button>
        </div>
      </div>
    </div>
  `).join('');
}

function setShopFilter(cat, btn) {
  shopFilter = cat;
  document.querySelectorAll('.shop-filter-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  renderProducts();
}

// ══════════════════════════════════════════
//  CART
// ══════════════════════════════════════════

function initCart() {
  const container = document.getElementById('cartItems');
  const summary   = document.getElementById('cartSummary');

  if (!cart.length) {
    container.innerHTML = `<div class="empty-state"><div class="empty-icon">🛒</div><h3>Your cart is empty</h3><p>Head to the shop and add some items!</p></div>`;
    summary.style.display = 'none';
    return;
  }

  const total = cart.reduce((sum, item) => sum + item.price * item.qty, 0);

  container.innerHTML = cart.map(item => `
    <div class="cart-row">
      <div class="cart-emoji">${item.emoji}</div>
      <div class="cart-info">
        <div class="cart-name">${item.name}</div>
        <div class="cart-price">$${item.price.toFixed(2)} each</div>
      </div>
      <div class="cart-qty">
        <button class="qty-btn" onclick="updateQty(${item.id}, -1)">−</button>
        <span>${item.qty}</span>
        <button class="qty-btn" onclick="updateQty(${item.id}, 1)">+</button>
      </div>
      <div class="cart-subtotal">$${(item.price * item.qty).toFixed(2)}</div>
      <button class="btn btn-ghost btn-sm" onclick="removeFromCart(${item.id})">✕</button>
    </div>
  `).join('');

  summary.style.display = 'block';
  document.getElementById('cartTotal').textContent = `$${total.toFixed(2)}`;
}

function checkout() {
  if (!currentUser) {
    showToast('Please log in to checkout!', 'error');
    openModal('authModal');
    return;
  }
  if (!cart.length) { showToast('Your cart is empty!', 'error'); return; }
  // 🔧 CONNECT STRIPE or another payment processor here
  showToast('🎉 Order placed! (Demo mode — no real charge)', 'success', 5000);
  cart = [];
  saveCart();
  initCart();
}

// ══════════════════════════════════════════
//  VIDEOS
// ══════════════════════════════════════════

// 🔧 ADD YOUR VIDEOS HERE
// For YouTube: get the video ID from the URL (the part after ?v=)
// For uploads: host on Firebase Storage or Cloudinary and paste the URL
const VIDEOS = [
  { id: 1, title: "Welcome to My Channel!",  thumb: "🎬", src: "https://www.youtube.com/embed/dQw4w9WgXcQ", type: "youtube", desc: "My very first video. Thanks for watching!" },
  { id: 2, title: "Behind the Scenes",       thumb: "🎥", src: "https://www.youtube.com/embed/dQw4w9WgXcQ", type: "youtube", desc: "A look at how I make content." },
  { id: 3, title: "Q&A — Your Questions!",   thumb: "❓", src: "https://www.youtube.com/embed/dQw4w9WgXcQ", type: "youtube", desc: "Answering the top questions from you all." },
];

let uploadedVideos = JSON.parse(localStorage.getItem('uploadedVideos') || '[]');

function initVideos() {
  renderVideos();
}

function renderVideos() {
  const allVideos = [...uploadedVideos, ...VIDEOS];
  const grid = document.getElementById('videoGrid');

  if (!allVideos.length) {
    grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1"><div class="empty-icon">📹</div><h3>No videos yet</h3></div>`;
    return;
  }

  grid.innerHTML = allVideos.map(v => `
    <div class="card video-card" onclick="openVideo(${JSON.stringify(v).replace(/"/g,'&quot;')})">
      <div class="video-thumb">${v.thumb || '🎬'}</div>
      <div class="video-info">
        <h3 class="video-title">${v.title}</h3>
        <p class="video-desc">${v.desc || ''}</p>
        <span class="badge badge-accent">${v.type === 'youtube' ? '▶ YouTube' : '📁 Upload'}</span>
      </div>
    </div>
  `).join('');
}

function openVideo(video) {
  const player = document.getElementById('videoPlayerContent');
  document.getElementById('videoPlayerTitle').textContent = video.title;

  if (video.type === 'youtube') {
    player.innerHTML = `<iframe src="${video.src}" frameborder="0" allowfullscreen style="width:100%;aspect-ratio:16/9;border-radius:8px;"></iframe>`;
  } else {
    player.innerHTML = `<video src="${video.src}" controls style="width:100%;border-radius:8px;"></video>`;
  }

  openModal('videoPlayerModal');
}

function handleVideoUpload() {
  if (!currentUser) { showToast('Please log in to upload videos!', 'error'); openModal('authModal'); return; }
  const title = document.getElementById('videoTitle').value.trim();
  const url   = document.getElementById('videoUrl').value.trim();
  const desc  = document.getElementById('videoDesc').value.trim();

  if (!title || !url) { showToast('Please fill in title and video URL', 'error'); return; }

  const isYT = url.includes('youtube.com') || url.includes('youtu.be');
  let src = url;
  if (isYT) {
    const match = url.match(/(?:v=|youtu\.be\/)([^&\s]+)/);
    if (match) src = `https://www.youtube.com/embed/${match[1]}`;
  }

  const video = { id: Date.now(), title, src, desc, thumb: '🎬', type: isYT ? 'youtube' : 'upload' };
  uploadedVideos.unshift(video);
  localStorage.setItem('uploadedVideos', JSON.stringify(uploadedVideos));

  document.getElementById('videoTitle').value = '';
  document.getElementById('videoUrl').value   = '';
  document.getElementById('videoDesc').value  = '';

  renderVideos();
  showToast('✅ Video posted!', 'success');
}

// ══════════════════════════════════════════
//  GAMES
// ══════════════════════════════════════════

const GAMES = [
  { id: 'snake',    name: "Snake",        emoji: "🐍", desc: "Classic snake game. Use arrow keys or swipe.",     color: "#22c55e" },
  { id: 'memory',   name: "Memory Match", emoji: "🃏", desc: "Flip cards and find matching pairs.",              color: "#00d4ff" },
  { id: 'tictactoe',name: "Tic Tac Toe",  emoji: "⭕", desc: "Two players, one board. First to 3 wins!",         color: "#f97316" },
  { id: 'clicker',  name: "Cookie Clicker",emoji:"🍪", desc: "Click as fast as you can. Build your score!",      color: "#f59e0b" },
];

function initGames() {
  const grid = document.getElementById('gamesGrid');
  grid.innerHTML = GAMES.map(g => `
    <div class="card game-card" onclick="launchGame('${g.id}')" style="--game-color:${g.color}">
      <div class="game-icon">${g.emoji}</div>
      <div class="game-info">
        <h3>${g.name}</h3>
        <p>${g.desc}</p>
      </div>
      <button class="btn btn-primary btn-sm">Play →</button>
    </div>
  `).join('');
}

function launchGame(gameId) {
  document.getElementById('gameArea').innerHTML = '';
  document.getElementById('gameTitle').textContent = GAMES.find(g => g.id === gameId)?.name || 'Game';
  openModal('gameModal');

  if (gameId === 'snake')     startSnake();
  if (gameId === 'memory')    startMemory();
  if (gameId === 'tictactoe') startTicTacToe();
  if (gameId === 'clicker')   startClicker();
}

// ── SNAKE ──
function startSnake() {
  const area = document.getElementById('gameArea');
  area.innerHTML = `
    <canvas id="snakeCanvas" width="300" height="300" style="border:1px solid var(--border);border-radius:8px;display:block;margin:0 auto;"></canvas>
    <div id="snakeScore" style="text-align:center;margin-top:0.8rem;font-size:1.1rem;font-weight:600;">Score: 0</div>
    <div style="text-align:center;color:var(--text-dim);font-size:0.8rem;margin-top:0.4rem;">Arrow keys / WASD to move</div>
    <div style="display:flex;gap:0.5rem;justify-content:center;margin-top:1rem;">
      <button class="btn btn-ghost btn-sm" onclick="startSnake()">↺ Restart</button>
    </div>
  `;

  const canvas = document.getElementById('snakeCanvas');
  const ctx = canvas.getContext('2d');
  const SIZE = 15, COLS = 20, ROWS = 20;
  let snake = [{x:10,y:10}], dir = {x:1,y:0}, food = randomFood(), score = 0, running = true;

  function randomFood() {
    return { x: Math.floor(Math.random()*COLS), y: Math.floor(Math.random()*ROWS) };
  }

  function draw() {
    ctx.fillStyle = '#0a0a0f';
    ctx.fillRect(0,0,300,300);
    // Food
    ctx.fillStyle = '#ef4444';
    ctx.fillRect(food.x*SIZE, food.y*SIZE, SIZE-1, SIZE-1);
    // Snake
    snake.forEach((seg,i) => {
      ctx.fillStyle = i === 0 ? '#00d4ff' : '#22c55e';
      ctx.fillRect(seg.x*SIZE, seg.y*SIZE, SIZE-1, SIZE-1);
    });
  }

  function step() {
    if (!running) return;
    const head = { x: snake[0].x + dir.x, y: snake[0].y + dir.y };
    if (head.x < 0 || head.x >= COLS || head.y < 0 || head.y >= ROWS ||
        snake.some(s => s.x === head.x && s.y === head.y)) {
      running = false;
      ctx.fillStyle = 'rgba(0,0,0,0.6)';
      ctx.fillRect(0,0,300,300);
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 20px Syne, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('Game Over! 💀', 150, 145);
      ctx.font = '14px DM Sans, sans-serif';
      ctx.fillText('Score: ' + score, 150, 170);
      return;
    }
    snake.unshift(head);
    if (head.x === food.x && head.y === food.y) {
      score++;
      food = randomFood();
      document.getElementById('snakeScore').textContent = 'Score: ' + score;
    } else {
      snake.pop();
    }
    draw();
    setTimeout(step, 120);
  }

  document.onkeydown = e => {
    if (!running) return;
    if (e.key==='ArrowUp'    || e.key==='w') { if(dir.y!==1)  dir={x:0,y:-1}; }
    if (e.key==='ArrowDown'  || e.key==='s') { if(dir.y!==-1) dir={x:0,y:1};  }
    if (e.key==='ArrowLeft'  || e.key==='a') { if(dir.x!==1)  dir={x:-1,y:0}; }
    if (e.key==='ArrowRight' || e.key==='d') { if(dir.x!==-1) dir={x:1,y:0};  }
  };

  draw();
  step();
}

// ── MEMORY ──
function startMemory() {
  const area = document.getElementById('gameArea');
  const icons = ['🍕','🎮','🐘','🌈','🦊','🎸','🍩','🚀'];
  let cards = [...icons,...icons].sort(()=>Math.random()-0.5).map((icon,i)=>({id:i,icon,flipped:false,matched:false}));
  let flipped=[], moves=0, matches=0;

  function render() {
    area.innerHTML = `
      <div style="text-align:center;margin-bottom:0.8rem;">Moves: <strong>${moves}</strong> | Matches: <strong>${matches}/8</strong></div>
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px;max-width:280px;margin:0 auto;">
        ${cards.map(c => `
          <div onclick="memoryFlip(${c.id})" style="
            height:60px;display:flex;align-items:center;justify-content:center;
            font-size:1.6rem;border-radius:8px;cursor:pointer;transition:all 0.2s;
            background:${c.flipped||c.matched ? 'var(--bg3)' : 'var(--accent2)'};
            border:1px solid ${c.matched ? 'var(--green)' : 'var(--border)'};
            ${c.matched ? 'opacity:0.5;' : ''}
          ">${c.flipped||c.matched ? c.icon : '?'}</div>
        `).join('')}
      </div>
      ${matches===8 ? '<div style="text-align:center;margin-top:1rem;font-size:1.1rem;">🎉 You won in '+moves+' moves!</div>' : ''}
      <div style="text-align:center;margin-top:1rem;"><button class="btn btn-ghost btn-sm" onclick="startMemory()">↺ Restart</button></div>
    `;
  }

  window.memoryFlip = (id) => {
    const card = cards[id];
    if (card.matched || card.flipped || flipped.length === 2) return;
    card.flipped = true;
    flipped.push(card);
    if (flipped.length === 2) {
      moves++;
      if (flipped[0].icon === flipped[1].icon) {
        flipped.forEach(c => c.matched = true);
        matches++;
        flipped = [];
        render();
      } else {
        render();
        setTimeout(() => { flipped.forEach(c => c.flipped=false); flipped=[]; render(); }, 900);
        return;
      }
    }
    render();
  };

  render();
}

// ── TIC TAC TOE ──
function startTicTacToe() {
  const area = document.getElementById('gameArea');
  let board = Array(9).fill(''), turn = 'X', gameOver = false;
  const wins = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];

  function checkWin(p) { return wins.some(([a,b,c]) => board[a]===p && board[b]===p && board[c]===p); }

  function render(msg='') {
    area.innerHTML = `
      <div style="text-align:center;margin-bottom:0.8rem;font-size:1rem;">
        ${msg || (gameOver ? '' : `Player <strong>${turn}</strong>'s turn`)}
      </div>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:6px;max-width:220px;margin:0 auto;">
        ${board.map((cell,i) => `
          <div onclick="tttMove(${i})" style="
            height:70px;display:flex;align-items:center;justify-content:center;
            font-size:2rem;font-weight:700;border-radius:8px;cursor:pointer;
            background:var(--bg3);border:1px solid var(--border);
            color:${cell==='X'?'var(--accent)':'var(--orange)'};
            ${gameOver||cell?'pointer-events:none;':''}
          ">${cell}</div>
        `).join('')}
      </div>
      <div style="text-align:center;margin-top:1rem;"><button class="btn btn-ghost btn-sm" onclick="startTicTacToe()">↺ Restart</button></div>
    `;
  }

  window.tttMove = (i) => {
    if (board[i] || gameOver) return;
    board[i] = turn;
    if (checkWin(turn)) { gameOver=true; render(`🏆 Player ${turn} wins!`); return; }
    if (board.every(c=>c)) { gameOver=true; render("🤝 It's a draw!"); return; }
    turn = turn==='X'?'O':'X';
    render();
  };

  render();
}

// ── CLICKER ──
function startClicker() {
  let score = 0, perClick = 1;
  const area = document.getElementById('gameArea');

  function render() {
    area.innerHTML = `
      <div style="text-align:center;">
        <div style="font-size:3.5rem;margin-bottom:0.5rem;cursor:pointer;transition:transform 0.1s;user-select:none;" id="cookieBtn" onclick="clickCookie()">🍪</div>
        <div style="font-size:1.8rem;font-weight:700;margin-bottom:1rem;">${score} cookies</div>
        <div style="display:flex;gap:0.5rem;justify-content:center;flex-wrap:wrap;">
          <button class="btn btn-secondary btn-sm" onclick="buyCursor()" ${score<10?'disabled':''}>🖱️ Cursor (+1/click) — 10 cookies</button>
          <button class="btn btn-secondary btn-sm" onclick="buyAuto()"   ${score<50?'disabled':''}>⚙️ Auto-clicker — 50 cookies</button>
        </div>
        <div style="color:var(--text-dim);font-size:0.8rem;margin-top:0.8rem;">+${perClick} per click</div>
      </div>
    `;
    const btn = document.getElementById('cookieBtn');
    if (btn) {
      btn.addEventListener('click', () => {
        btn.style.transform = 'scale(0.88)';
        setTimeout(()=>btn.style.transform='scale(1)',80);
      });
    }
  }

  window.clickCookie = () => { score += perClick; render(); };
  window.buyCursor   = () => { if(score>=10){ score-=10; perClick++; render(); } };
  window.buyAuto     = () => {
    if(score>=50){
      score-=50;
      setInterval(()=>{ score+=perClick; render(); },1000);
      showToast('⚙️ Auto-clicker enabled!','success');
      render();
    }
  };

  render();
}

// ══════════════════════════════════════════
//  PROFILE
// ══════════════════════════════════════════

function initProfile() {
  const container = document.getElementById('profileContent');

  if (!currentUser) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">👤</div>
        <h3>Not logged in</h3>
        <p>Create an account or log in to see your profile.</p>
        <button class="btn btn-primary" style="margin-top:1rem;" onclick="openModal('authModal')">Login / Sign Up</button>
      </div>`;
    return;
  }

  container.innerHTML = `
    <div class="profile-header">
      <div class="profile-avatar">${currentUser.avatar || '👤'}</div>
      <div class="profile-details">
        <h2>${currentUser.name}</h2>
        <p style="color:var(--text-dim)">${currentUser.email}</p>
        <p style="color:var(--text-dim);font-size:0.85rem;">Member since ${currentUser.joined || 'today'}</p>
      </div>
    </div>
    <hr class="divider">
    <h3 style="margin-bottom:1rem;">Edit Profile</h3>
    <div class="form-group">
      <label>Display Name</label>
      <input class="form-control" id="editName" value="${currentUser.name}" placeholder="Your name">
    </div>
    <div class="form-group">
      <label>Bio</label>
      <textarea class="form-control" id="editBio" rows="3" placeholder="Tell people about yourself...">${currentUser.bio||''}</textarea>
    </div>
    <div class="form-group">
      <label>Avatar (pick an emoji)</label>
      <div style="display:flex;gap:0.5rem;flex-wrap:wrap;margin-top:0.3rem;">
        ${['👤','😎','🎮','🦊','🐘','🚀','🎸','👾','🌈','🍕'].map(em=>`
          <span onclick="selectAvatar('${em}')" style="font-size:1.6rem;cursor:pointer;padding:0.3rem;border-radius:8px;border:2px solid ${currentUser.avatar===em?'var(--accent)':'transparent'};transition:border 0.15s;" id="av-${em}">${em}</span>
        `).join('')}
      </div>
    </div>
    <div style="display:flex;gap:0.8rem;flex-wrap:wrap;margin-top:1rem;">
      <button class="btn btn-primary" onclick="saveProfile()">Save Changes</button>
      <button class="btn btn-danger"  onclick="logout()">Log Out</button>
    </div>
  `;
}

function selectAvatar(emoji) {
  currentUser.avatar = emoji;
  document.querySelectorAll('[id^="av-"]').forEach(el => el.style.border = '2px solid transparent');
  const el = document.getElementById('av-' + emoji);
  if (el) el.style.border = '2px solid var(--accent)';
}

function saveProfile() {
  currentUser.name = document.getElementById('editName').value.trim() || currentUser.name;
  currentUser.bio  = document.getElementById('editBio').value.trim();

  // Update in demoUsers store
  const idx = demoUsers.findIndex(u => u.id === currentUser.id);
  if (idx !== -1) { demoUsers[idx] = currentUser; localStorage.setItem('demoUsers', JSON.stringify(demoUsers)); }
  localStorage.setItem('demoSession', JSON.stringify(currentUser));

  updateNavAuth();
  showToast('✅ Profile saved!', 'success');
  initProfile();
}
