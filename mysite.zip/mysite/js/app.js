/* ============================================
   app.js — Core app logic
   Handles: routing, auth, cart, toast, Firebase
   ============================================ */

// ── FIREBASE CONFIG ──
// 🔧 REPLACE THESE VALUES with your own from Firebase Console
// Instructions in README.md
const firebaseConfig = {
  apiKey:            "YOUR_API_KEY",
  authDomain:        "YOUR_PROJECT.firebaseapp.com",
  projectId:         "YOUR_PROJECT_ID",
  storageBucket:     "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId:             "YOUR_APP_ID"
};

// ── DEMO MODE ──
// When Firebase isn't set up yet, the site runs in demo mode
// Set this to false once you add your Firebase config above
const DEMO_MODE = true;

let currentUser = null;

// ── DEMO USER STORE ──
let demoUsers = JSON.parse(localStorage.getItem('demoUsers') || '[]');
let demoSession = JSON.parse(localStorage.getItem('demoSession') || 'null');

if (demoSession) {
  currentUser = demoSession;
}

// ── ROUTER ──
function showPage(pageId) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-links a').forEach(a => a.classList.remove('active'));

  const page = document.getElementById('page-' + pageId);
  if (page) page.classList.add('active');

  const link = document.querySelector(`.nav-links a[data-page="${pageId}"]`);
  if (link) link.classList.add('active');

  // Close mobile menu
  document.getElementById('navLinks').classList.remove('open');

  // Run page-specific init
  if (pageId === 'shop')    initShop();
  if (pageId === 'videos')  initVideos();
  if (pageId === 'games')   initGames();
  if (pageId === 'profile') initProfile();
  if (pageId === 'cart')    initCart();

  window.scrollTo({ top: 0 });
}

// ── NAVBAR ──
document.querySelectorAll('.nav-links a[data-page]').forEach(link => {
  link.addEventListener('click', e => {
    e.preventDefault();
    showPage(link.dataset.page);
  });
});

document.getElementById('menuToggle').addEventListener('click', () => {
  document.getElementById('navLinks').classList.toggle('open');
});

// ── TOAST ──
function showToast(message, type = 'info', duration = 3000) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.className = `show ${type}`;
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => toast.classList.remove('show'), duration);
}

// ── CART ──
let cart = JSON.parse(localStorage.getItem('cart') || '[]');

function saveCart() {
  localStorage.setItem('cart', JSON.stringify(cart));
  updateCartBadge();
}

function updateCartBadge() {
  const count = cart.reduce((sum, item) => sum + item.qty, 0);
  document.getElementById('cartCount').textContent = count;
  document.getElementById('cartCount').style.display = count > 0 ? 'inline' : 'none';
}

function addToCart(product) {
  const existing = cart.find(i => i.id === product.id);
  if (existing) {
    existing.qty++;
  } else {
    cart.push({ ...product, qty: 1 });
  }
  saveCart();
  showToast(`🛒 ${product.name} added to cart!`, 'success');
}

function removeFromCart(productId) {
  cart = cart.filter(i => i.id !== productId);
  saveCart();
  initCart();
}

function updateQty(productId, delta) {
  const item = cart.find(i => i.id === productId);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) removeFromCart(productId);
  else { saveCart(); initCart(); }
}

// ── AUTH HELPERS ──
function updateNavAuth() {
  const loginBtn  = document.getElementById('navLoginBtn');
  const userChip  = document.getElementById('navUserChip');
  const userName  = document.getElementById('navUserName');

  if (currentUser) {
    loginBtn.style.display  = 'none';
    userChip.style.display  = 'flex';
    userName.textContent = currentUser.name || currentUser.email.split('@')[0];
  } else {
    loginBtn.style.display  = 'inline-flex';
    userChip.style.display  = 'none';
  }
}

function logout() {
  currentUser = null;
  localStorage.removeItem('demoSession');
  updateNavAuth();
  showToast('Logged out. See you soon! 👋', 'info');
  showPage('home');
}

// ── MODAL HELPERS ──
function openModal(id) {
  document.getElementById(id).classList.add('open');
}

function closeModal(id) {
  document.getElementById(id).classList.remove('open');
}

// Close modal on overlay click
document.querySelectorAll('.modal-overlay').forEach(overlay => {
  overlay.addEventListener('click', e => {
    if (e.target === overlay) overlay.classList.remove('open');
  });
});

// ── AUTH FORMS ──
document.getElementById('loginForm').addEventListener('submit', e => {
  e.preventDefault();
  const email = document.getElementById('loginEmail').value.trim();
  const pass  = document.getElementById('loginPass').value;

  if (DEMO_MODE) {
    const user = demoUsers.find(u => u.email === email && u.password === pass);
    if (!user) { showToast('❌ Wrong email or password', 'error'); return; }
    currentUser = user;
    localStorage.setItem('demoSession', JSON.stringify(user));
    closeModal('authModal');
    updateNavAuth();
    showToast(`Welcome back, ${user.name}! 👋`, 'success');
    showPage('profile');
  }
});

document.getElementById('signupForm').addEventListener('submit', e => {
  e.preventDefault();
  const name  = document.getElementById('signupName').value.trim();
  const email = document.getElementById('signupEmail').value.trim();
  const pass  = document.getElementById('signupPass').value;

  if (DEMO_MODE) {
    if (demoUsers.find(u => u.email === email)) {
      showToast('❌ Email already registered', 'error'); return;
    }
    const user = { id: Date.now(), name, email, password: pass, avatar: '👤', bio: '', joined: new Date().toLocaleDateString() };
    demoUsers.push(user);
    localStorage.setItem('demoUsers', JSON.stringify(demoUsers));
    currentUser = user;
    localStorage.setItem('demoSession', JSON.stringify(user));
    closeModal('authModal');
    updateNavAuth();
    showToast(`Welcome, ${name}! 🎉`, 'success');
    showPage('profile');
  }
});

// Tab switching in auth modal
document.querySelectorAll('.auth-tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.auth-panel').forEach(p => p.classList.remove('active'));
    tab.classList.add('active');
    document.getElementById(tab.dataset.panel).classList.add('active');
  });
});

document.getElementById('navLoginBtn').addEventListener('click', () => openModal('authModal'));
document.getElementById('navUserChip').addEventListener('click', () => showPage('profile'));

// ── INIT ──
updateCartBadge();
updateNavAuth();
showPage('home');
